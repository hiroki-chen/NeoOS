#![no_std] // don't link the Rust standard library
#![no_main] // disable all Rust-level entry points
#![allow(clippy::single_component_path_imports)]
#![allow(unused_imports)]

use kernel;
