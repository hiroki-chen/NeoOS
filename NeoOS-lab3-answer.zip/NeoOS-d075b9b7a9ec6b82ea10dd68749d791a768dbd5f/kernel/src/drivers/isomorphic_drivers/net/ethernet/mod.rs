//! Ethernet drivers

pub mod intel;
pub mod structs;
