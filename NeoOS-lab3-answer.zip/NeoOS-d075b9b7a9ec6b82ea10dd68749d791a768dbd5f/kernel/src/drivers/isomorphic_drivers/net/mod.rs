//! Network drivers

pub mod ethernet;
