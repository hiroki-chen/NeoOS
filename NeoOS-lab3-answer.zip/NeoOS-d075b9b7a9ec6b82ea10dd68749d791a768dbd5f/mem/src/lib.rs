#![no_std]

extern crate alloc;

pub mod buddy_allocator;
